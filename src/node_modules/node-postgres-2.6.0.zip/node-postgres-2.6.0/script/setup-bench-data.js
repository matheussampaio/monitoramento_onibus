var pg = require('../lib');
var 
pg.connect(function(err, client) {
  
})
